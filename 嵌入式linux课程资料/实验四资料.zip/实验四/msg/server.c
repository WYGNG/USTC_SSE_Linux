#include <stdio.h>
#include<stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string.h>

#define KEY_MSG 0x101
#define MSGSIZE 64

typedef struct{
	long mtype;
	char mtext[MSGSIZE];
}msgbuf;

#define LEN sizeof(msgbuf) - sizeof(long)

int main()
{
	int msgid;
	msgbuf buf1, buf2;
	msgid = msgget( KEY_MSG, IPC_CREAT| 0666 );
	while(1){
		msgrcv(msgid, &buf1, LEN, 1L, 0);
		printf("receive client1 message: %s\n", buf1.mtext);
		if(buf1.mtext[0] == 'x' || buf1.mtext[0] == 'X'){
			strcpy(buf1.mtext, "x");
			buf1.mtype = 3L;
			msgsnd(msgid, &buf1, LEN, 0);
			buf1.mtype = 4L;
			msgsnd(msgid, &buf1, LEN, 0);
			break;
		}
		buf1.mtype = 4L;
		msgsnd( msgid, &buf1, LEN, 0);


		msgrcv( msgid, &buf2, LEN, 2L, 0 );
		printf("receive client2 message: %s\n", buf2.mtext);
		if(buf2.mtext[0] == 'x' || buf2.mtext[0] == 'X'){
			strcpy(buf2.mtext, "x");
			buf2.mtype = 3L;
			msgsnd(msgid, &buf2, LEN, 0);
			buf2.mtype = 4L;
			msgsnd(msgid, &buf2, LEN, 0);
			break;
		}

		buf2.mtype = 3L;
		msgsnd(msgid, &buf2, LEN, 0);
	}

	sleep(1);
	msgctl( msgid, IPC_RMID, NULL );
	exit(0);
}
