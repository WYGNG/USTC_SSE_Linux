#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <string.h>
#include <errno.h>

typedef struct sockaddr SA;
#define N 64

int main(int argc, char *argv[])
{

	int sockfd;
	ssize_t n;
	struct sockaddr_in servaddr;
	char buf[N] = {0};

	if(argc < 3){
		printf("Usage: %s ip port\n", argv[0]);
		return 0;
	}

	if((sockfd = socket(PF_INET, SOCK_STREAM, 0)) == -1){
		perror("socket");
		exit(-1);
	}

	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family = PF_INET;
	servaddr.sin_port = htons(atoi(argv[2]));
	servaddr.sin_addr.s_addr = inet_addr(argv[1]);

	if((n = connect(sockfd, (SA *)&servaddr, sizeof(servaddr))) == -1){
		perror("connect");
		exit(-1);
	}

	printf(">");
	while(fgets(buf, N, stdin) != NULL){
		buf[strlen(buf) - 1] = '\0';
		send(sockfd, buf, N, 0);

		bzero(buf, sizeof(buf));
		n = recv(sockfd, buf, N ,0);
		printf("n=%d buf=%s\n",n,buf);
		printf(">");
	}

	close(sockfd);

	return 0;
}
