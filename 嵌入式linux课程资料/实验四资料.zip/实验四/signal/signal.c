#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>

int wait_mark;
void waiting(), stop();

int main(int argc, char *argv[])
{
	int p1, p2;
	signal(SIGINT, stop);

	while((p1 = fork()) == -1);

	if(p1 > 0){
		while((p2 = fork()) == -1);
		if(p2 > 0){
			wait_mark = 1;
			kill(getpid(), SIGINT);
			waiting();
			printf("p1: %d ;  p2 %d\n", p1, p2);
			kill(p1, 10);
			kill(p2, 12);
			wait(NULL);
			wait(NULL);
			printf("parent process exit\n");
			exit(0);
		}
		else{
			printf("child process 2 is creat by parent\n");
			wait_mark = 1;
			signal(12, stop);
			waiting();
			lockf(1, 1, 0); // 0 for stdin, 1 for stdout, 2 for stderr
			printf("child process 2 is killed by parent\n");
			lockf(1, 0, 0);
			exit(0);
		}
	}
	else{
			printf("child process 1 is creat by parent\n");
			wait_mark = 1;
			signal(10, stop);
			waiting();
			lockf(1, 1, 0);
			printf("child process 1 is killed by parent\n");
			lockf(1, 0, 0);
			exit(0);
	}
}

void waiting()
{
	while(wait_mark != 0){}
}

void stop()
{
	wait_mark = 0;
}
