gcc -o create_fifo create_fifo.c
gcc -o read_fifo  read_fifo.c
gcc -o write_fifo write_fifo.c





